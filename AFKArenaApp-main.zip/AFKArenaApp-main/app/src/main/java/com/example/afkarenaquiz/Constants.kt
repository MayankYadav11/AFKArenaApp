package com.example.afkarenaquiz

import java.util.*

object Constants {
    fun getQuestions(): ArrayList<Question> {
        val questionsList = ArrayList<Question>()
        val q1 = Question(1, "What Celestial hero is this?", R.drawable.athalia, "Mehira", "Antandra", "Silvina", "Athalia", 4)
        questionsList.add(q1)

        val q2 = Question(2,"What Mauler hero is this?", R.drawable.golus,"Ogi", "Golus","Thoran","Vurk",2)
        questionsList.add(q2)

        val q3 = Question(3, "How many types of furnitures are there at the Oak Inn which give Attribute Bonuses", R.drawable.oakInn, "1", "2", "3", "4", 3)
        questionsList.add(q3)

        val q4 = Question(4,"Which hero faction can be used at the Tower of Light?", R.drawable.factions, "Maulers", "Graveborns", "Wilders", "Lightbearers", 4)
        questionsList.add(q4)

        val q5 = Question(5,"In the Arcanists Unicon story, Vedan - the Demise adopted who?",R.drawable.vedan,"Silvina", "Kelthur","Daimon", "Silas", 1)
        questionsList.add(q5)

        val q6 = Question(6,"Who is Mehira - Mind Cager obsessed with?",R.drawable.mehira,"Tasi", "Safiya", "Fawkes", "Thoran", 3)
        questionsList.add(q6)

        val q7 = Question(7,"Who can start the Guild Team Hunting", R.drawable.guildHunting,"Guild Member", "Soren", "Auto", "Guild Master & Guild Deputy",4)
        questionsList.add(q7)

        val q8 = Question(8,"Dimensional Heroes", R.drawable.dimensional,"Have factional advantage against Dimensional Heroes", "Cannot be affected by faction advantages","Have factional advantage against all Factions", "Have factional advantages against Celestial and Hypogean heroes",2)
        questionsList.add(q8)

        val q9 = Question(9,"At what tier do Heroes enter the Oak Inn?",R.drawable.oakInn, "Legendary", "Mythic", "Ascended", "Elite", 3)
        questionsList.add(q9)

        val q10 = Question(10,"Khazard - The Frozen Terror is which hero's predecessor?", R.drawable.khazard,"Seirus", "Saurus", "Vedan","Tidus",1)
        questionsList.add(q10)

        return questionsList
    }
}